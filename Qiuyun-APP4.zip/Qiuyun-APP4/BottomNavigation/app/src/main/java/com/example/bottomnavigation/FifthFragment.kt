package com.example.bottomnavigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import org.json.JSONObject
import java.net.URL
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy


class FifthFragment : Fragment() {

    companion object
    {
        private var instance : FifthFragment? = null
        public fun getInstance() : FifthFragment
        {
            return instance!!
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance=this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fifth, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.hide()

        var webview = MainActivity.getInstance().findViewById<WebView>(R.id.webview)
        var arguments = this.getArguments()
        var song = arguments?.getString("songName")
        var song1 = song!!.replace(" ","+")
        var artist = "The Beatles"
        var origSong = song!!
        var artist1 = artist.replace(" ","+")
        val keywords = artist1+"+"+song1
        val max = 50
        val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=$keywords&order=viewCount&maxResults=$max&type=video&videoCategory=Music&key=AIzaSyDtzKWgA0ne39VD_-i0oJwCd4WOdFKZy4I"
        var helper = Helper(url, origSong, artist)
        var thread = Thread(helper)
        thread.start()
    }
}

class Helper : Runnable
{
    private var url : String = ""
    private var song : String = ""
    private var artist : String = ""

    constructor(url: String, song: String, artist: String)
    {
        this.url = url
        this.song = song
        this.artist = artist
    }
    override fun run() {
        var data = URL(url).readText()
        println(data)
        var json = JSONObject(data)
        var items = json.getJSONArray("items")
        var titles = ArrayList<String>()
        var videos = ArrayList<String>()
        for (i in 0..(items.length() - 1)) {
            var videoObjest = items.getJSONObject(i)
            var idDict = videoObjest.getJSONObject("id")
            var videoId = idDict.getString("videoId")
            var snippetDict = videoObjest.getJSONObject("snippet")
            var title = snippetDict.getString("title")
            titles.add(title)
            videos.add(videoId)
        }

        var best_video :Int = 0
        for (i in 0..titles.size - 1) {
            var artist_index = titles[i].contains(artist)
            var song_index = titles[i].contains(song)
            if ((artist_index != false) && (song_index != false)) {
                best_video = i
            }
        }


        var selected_video: String = ""
        selected_video = videos[best_video]
        var helper1 = UIThreadHelper(selected_video)
        MainActivity.getInstance().runOnUiThread(helper1)
    }
}

class UIThreadHelper :Runnable
{
    private var video : String = ""
    constructor(video: String)
    {
        this.video = video
    }
    public override fun run()
    {
        //Update the webView
        var web = MainActivity.getInstance().findViewById<WebView>(R.id.webview)
        val settings = web.getSettings()
        settings.setJavaScriptEnabled(true)
        settings.setDomStorageEnabled(true)
        settings.setMinimumFontSize(10)
        settings.setLoadWithOverviewMode(true)
        settings.setUseWideViewPort(true)
        settings.setBuiltInZoomControls(true)
        settings.setDisplayZoomControls(false)
        web.setVerticalScrollBarEnabled(false)
        settings.setDomStorageEnabled(true)
        web.setWebViewClient(WebViewClient())
        var str = "https://www.youtube.com/watch?v=" + video
        web.loadUrl(str)
    }
}