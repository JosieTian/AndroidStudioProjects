package com.example.bottomnavigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.*
import androidx.navigation.Navigation
import kotlin.contracts.contract


class FourthFragment : Fragment() {

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<RecyclerAdapter1.ViewHolder>? = null

    companion object
    {
        private var instance : FourthFragment? = null
        public fun getInstance() : FourthFragment
        {
            return instance!!
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fourth, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Songs")

        var arguments = this.getArguments()
        //var pos = arguments?.getInt("position")
        var pos = arguments?.getString("albumName")
        layoutManager = LinearLayoutManager(MainActivity.getInstance())
        var recycler_view1 = MainActivity.getInstance().findViewById<RecyclerView>(R.id.recycler_view1)
        recycler_view1.layoutManager = layoutManager
        adapter = RecyclerAdapter1(pos!!) //this is the desired contact selected
        recycler_view1.adapter = adapter


    }
}

class RecyclerAdapter1  : RecyclerView.Adapter<RecyclerAdapter1.ViewHolder> {
    private var pos : String? = null
    private var arrayInfo = arrayOf<Array<String>>()
  constructor(pos : String) : this()
    {
        this.pos=pos
    }

    constructor() {
    }

    public fun setPos(pos: String?) {
        this.pos = pos
    }
    public fun getPos() : String?
    {
        return pos
    }

    override fun getItemCount(): Int {
        var is1 = MainActivity.getInstance().getAssets().open("${getPos()}.txt")
        var reader1 = BufferedReader(InputStreamReader(is1))
        var lines1 = reader1.readLines()
        var songName = lines1.toTypedArray()
        return songName.size
    }
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerAdapter1.ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.song_layout, parent, false)
        return ViewHolder(v)
    }
    override fun onBindViewHolder(holder: RecyclerAdapter1.ViewHolder, position: Int) {
        var is1 = MainActivity.getInstance().getAssets().open("${getPos()}.txt")
        var reader1 = BufferedReader(InputStreamReader(is1))
        var lines1 = reader1.readLines()
        var songName = lines1.toTypedArray()
        for (i in 0..songName.size - 1) {
            var array1 = songName[i].split("^")
            arrayInfo += array1.toTypedArray()
        }
        holder.songName.text = arrayInfo[position][0]
        holder.composer.text = arrayInfo[position][1]
    }
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var songName: TextView
        var composer: TextView

        init {
            songName = itemView.findViewById(R.id.songName)
            composer = itemView.findViewById(R.id.composer)
            var handler = Handler()
            itemView.setOnClickListener(handler)
        }
        inner class Handler() : View.OnClickListener
        {
            override fun onClick(v: View?)
            {
                val itemPosition = getLayoutPosition()
                var songName1 = arrayInfo[itemPosition][0]
                var navController = Navigation.findNavController(FourthFragment.getInstance().requireView()!!)
                val bundle = Bundle()
                bundle.putString("songName", songName1)
                navController.navigate(R.id.songToVideo, bundle)
            }
        }
    }
}