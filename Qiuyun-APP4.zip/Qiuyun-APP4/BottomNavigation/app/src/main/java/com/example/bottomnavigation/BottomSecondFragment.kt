package com.example.bottomnavigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class BottomSecondFragment : Fragment() {

  private var layoutManager : RecyclerView.LayoutManager? = null
  private var adapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>? = null

  companion object
  {
    private var instance : BottomSecondFragment? = null
    public fun getInstance() : BottomSecondFragment
    {
      return instance!!
    }
  }

  //initial non-widget datafields
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    instance = this
  }

  override fun onCreateView(
    inflater: LayoutInflater, container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    // Inflate the layout for this fragment
    return inflater.inflate(R.layout.fragment_bottom_second, container, false)
  }

  //initial all widgets
  //where the back button goes
  override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
    MainActivity.getInstance().getSupportActionBar()?.setTitle("Album")

    layoutManager = LinearLayoutManager(MainActivity.getInstance())
    var recycler_view = MainActivity.getInstance().findViewById<RecyclerView>(R.id.recycler_view)
    recycler_view.layoutManager = layoutManager
    adapter = RecyclerAdapter()
    recycler_view.adapter = adapter
  }
}


class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>()
{
  private var allAlbum = arrayOf(
    Album("Please Please me", "March 22, 1963", "pleasepleaseme"),
    Album("With The Beatles", "November 22, 1963", "with_the_beatles"),
    Album("A Hard Day's Night", "July 10, 1964", "harddaysnight"),
    Album("Beatles For Sale", "December 4, 1964", "beatlesforsale"),
    Album("Help!", "August 6, 1965", "help"),
    Album("Rubber Soul", "December 3, 1965", "rubber_soul"),
    Album("Revolver", "August 5, 1966", "revolver"),
    Album("Sgt. Pepper's Lonely Hearts", "June 1, 1967", "sgt_pepper"),
    Album("Magical Mystery Tour", "December 6, 1967", "magicalmysterytour"),
    Album("Yellow Submarine", "January 17, 1969", "yellowsubmarine"),
    Album("The Beatles(The White Album", "November 22, 1968", "white"),
    Album("Abbey Road", "September 26, 1969", "abbeyroad"),
    Album("Let It Be", "May 8, 1970", "letitbe"),
    Album("Past Masters Volume 1", "March 7, 1988", "pastmastersvolume1"),
    Album("Past Masters Volume 2", "March 7, 1988", "pastmastersvolume2")
  )

  override fun getItemCount() : Int
  {
    return allAlbum.size
  }

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder
  {
    val v = LayoutInflater.from(parent.context).inflate(R.layout.card_layout, parent, false)
    return ViewHolder(v)
  }

  override fun onBindViewHolder(holder: ViewHolder, position: Int) {
    holder.itemName.text = allAlbum[position].getName()
    holder.itemPro.text = allAlbum[position].getProducer()
    holder.itemImage.setImageResource(MainActivity.getInstance().resources.getIdentifier(allAlbum[position].getPic(), "drawable", MainActivity.getInstance().packageName))
  }

  inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
  {
    var itemName : TextView
    var itemPro : TextView
    var itemImage : ImageView

    init
    {
      itemName = itemView.findViewById(R.id.name)
      itemPro = itemView.findViewById(R.id.pro)
      itemImage = itemView.findViewById(R.id.imageView1)
      var handler = Handler()
      itemView.setOnClickListener(handler)
    }

    inner class Handler() : View.OnClickListener
    {
      override fun onClick(v: View?)
      {
        val itemPosition = getLayoutPosition()
        var songName = allAlbum[itemPosition].getPic()
        var navController = Navigation.findNavController(BottomSecondFragment.getInstance().requireView()!!)
        val bundle = Bundle()
        bundle.putInt("position", itemPosition)
        bundle.putString("albumName", songName)
        navController.navigate(R.id.albumToSong, bundle)

      }
    }
  }

}