package com.example.bottomnavigation

class Album {
    private var name : String = ""
    private var producer : String = ""
    private var pic : String = ""

    constructor(name : String, producer : String, pic: String)
    {
        this.name = name
        this.producer = producer
        this.pic = pic
    }
    public fun setName(name: String)
    {
        this.name = name
    }
    public fun getName() : String
    {
        return name
    }
    public fun setProducer(producer : String)
    {
        this.producer = producer
    }
    public fun getProducer() : String
    {
        return producer
    }
    public fun setPic(pic : String)
    {
        this.pic = pic
    }
    public fun getPic() : String
    {
        return pic
    }
}