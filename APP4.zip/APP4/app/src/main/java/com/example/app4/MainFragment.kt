package com.example.app4

import android.media.Image
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import java.io.*

class MainFragment : Fragment() {

    companion object
    {
        private var instance: MainFragment? = null
        public fun getInstance() : MainFragment
        {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Home")

        var quiz = Quiz()
        quiz.start()
    }
}

class Quiz : Thread
{
    private var duration : Long = 0
    private var imageView : ImageView? = null

    constructor()
    {
        duration = 3
        imageView = MainFragment.getInstance().view?.findViewById(R.id.imageView)
    }

    override public fun run()
    {
        var pics = arrayOf("intro1", "abbeyroad", "beatlesforsale", "harddaysnight", "help", "letitbe", "magicalmysterytour", "pastmastersvolume1", "pastmastersvolume2", "pleasepleaseme", "revolver", "rubber_soul", "sgt_pepper", "white", "with_the_beatles", "yellowsubmarine")
        while(true)
        {
            for(i in 0..pics.size-1)
            {
                var handler = HandlerThread(pics[i])
                MainActivity.getInstance().runOnUiThread(handler)
                Thread.sleep(duration*1000)
            }
        }
    }

    class HandlerThread : Runnable
    {
        private var pic : String = ""
        constructor(pic: String)
        {
            this.pic = pic
        }
        override fun run()
        {
            var imageView = MainFragment.getInstance().view?.findViewById<ImageView>(R.id.imageView)
            if (imageView != null)
            {
                var id = MainActivity.getInstance().resources.getIdentifier(pic, "drawable", MainActivity.getInstance().packageName )
                imageView?.setImageResource(id)
            }
        }
    }
}