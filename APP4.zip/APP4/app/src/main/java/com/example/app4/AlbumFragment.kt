package com.example.app4

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class AlbumFragment : Fragment() {

    private var layoutManager : RecyclerView.LayoutManager? = null
    private var adapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>? = null

    companion object
    {
        private var instance : AlbumFragment? = null
        public fun getInstance() : AlbumFragment
        {
            return instance!!
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_album, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Album")

        layoutManager = LinearLayoutManager(MainActivity.getInstance())
        var recycler_view = MainActivity.getInstance().findViewById<RecyclerView>(R.id.recycler_view)
        recycler_view.layoutManager = layoutManager
        adapter = RecyclerAdapter()
        recycler_view.adapter = adapter
    }


}



class Album
{
    private var name : String = ""
    private var producer : String = ""
    private var pic : String = ""

    constructor(name : String, producer : String, pic: String)
    {
        this.name = name
        this.producer = producer
        this.pic = pic
    }
    public fun setName(name: String)
    {
        this.name = name
    }
    public fun getName() : String
    {
        return name
    }
    public fun setProducer(producer : String)
    {
        this.producer = producer
    }
    public fun getProducer() : String
    {
        return producer
    }
    public fun setPic(pic : String)
    {
        this.pic = pic
    }
    public fun getPic() : String
    {
        return pic
    }
}

class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>()
{
    private var allAlbum = arrayOf(Album("Please Please me", "March 22, 1963", "pleasepleaseme"), Album("With The Beatles", "November 22, 1963", "with_the_beatles"), Album("A Hard Day's Night", "July 10, 1964", "harddaysnight"))

    override fun getItemCount() : Int
    {
        return allAlbum.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder
    {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.card_layout, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemName.text = allAlbum[position].getName()
        holder.itemPro.text = allAlbum[position].getProducer()
        holder.itemImage.setImageResource(MainActivity.getInstance().resources.getIdentifier(allAlbum[position].getPic(), "drawable", MainActivity.getInstance().packageName))
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        var itemName : TextView
        var itemPro : TextView
        var itemImage : ImageView

        init
        {
            itemName = itemView.findViewById(R.id.name)
            itemPro = itemView.findViewById(R.id.pro)
            itemImage = itemView.findViewById(R.id.imageView)
            //var handler = Handler()
            //itemView.setOnClickListener(handler)
        }
        /*
        inner class Handler() : View.OnClickListener
        {
            override fun onClick(v: View?)
            {
                val itemPosition = getLayoutPosition()


            }
        }*/
    }

}