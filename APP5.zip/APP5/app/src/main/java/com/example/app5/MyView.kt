

package com.example.app5

import android.app.AlertDialog
import android.content.DialogInterface.*
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.jar.Manifest
import kotlin.collections.ArrayList
import kotlin.math.*
import android.view.View.*
import android.content.DialogInterface

class MyView : View {
    private var x1 : Float = 0.0f
    private var y1 : Float = 0.0f
    private var x2 : Float = 0.0f
    private var y2 : Float = 0.0f
    private var paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var targets = ArrayList<Drawable>()
    private var start : Boolean = true
    private var score : Int = 0
    private var shots : Int = 0
    private var timer = Timer()
    private var path = Path()
    private var ball1 : Drawable? = null
    private var ballCoords: Rect = Rect(0, 0, 0, 0)
    private var bugCoords : Rect = Rect(0,0,0,0)
    private val gravity : Double = 9.8
    private var second : Int = 1
    private var fire : Boolean = true

    companion object {
        private var instance: MyView? = null
        public fun getInstance(): MyView {
            return instance!!
        }
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    {
        instance = this
    }
    public fun getX1(): Float {
        return x1
    }

    public fun getY1(): Float {
        return y1
    }
    public fun getX2(): Float {
        return x2
    }

    public fun getY2(): Float {
        return y2
    }
    public fun setpathMove(x1:Float,y1:Float)
    {
        this.x1=x1
        this.y1=y1
    }
    public fun setpathLine(x2:Float,y2:Float)
    {
        this.x2=x2
        this.y2=y2
    }
    public fun setBallCoords(ux: Int, uy: Int, lx: Int, ly: Int) {
        this.ballCoords.set(ux, uy, lx, ly)
    }
    public fun getBallCoords(): Rect {
        return ballCoords
    }
    public fun setBugCoords(ux: Int, uy: Int, lx: Int, ly: Int) {
        this.bugCoords.set(ux, uy, lx, ly)
    }
    public fun getBugCoords(): Rect {
        return bugCoords
    }

    public fun update() {
        if (!start) {
            second = second+1
            var velocity = MainActivity.getInstance().findViewById<TextView>(R.id.speed).getText()
            var vel = velocity.toString().toInt()
            var pro = MainActivity.getInstance().findViewById<TextView>(R.id.degree).getText()
            var process = pro.toString().toInt()
            var po = (90 - process).toDouble()
            var x1 = getX1().toInt()
            var y1 = (getY1() - height*0.02).toInt()
            ballCoords.left = ((vel * (Math.cos(Math.toRadians(po))) * second)+x1 ).toInt()
            ballCoords.top = ((-vel * (Math.sin(Math.toRadians(po))) * second + 0.5 * gravity * second * second)+y1).toInt()
            ballCoords.right = (ballCoords.left + 0.015 * width).toInt()
            ballCoords.bottom = (ballCoords.top + 0.03 * height).toInt()
            ball1?.setBounds(ballCoords.left, ballCoords.top, ballCoords.right, ballCoords.bottom)
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        for (i in 0..targets.size - 1) {
            var drawable = targets.get(i)
            drawable.draw(canvas!!)
        }

        var stroke : Float = 0.0013f
        paint.setColor(Color.BLACK)
        paint.setStyle(Paint.Style.STROKE)
        stroke = (width * 0.009).toFloat()
        paint.setStrokeWidth(stroke)
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        canvas?.drawPath(path, paint)

        if (!start) {
            ball1!!.draw(canvas!!)
            for (i in 0..targets.size-2) {
                var drawable = targets.get(i)
                var a = drawable.getBounds()
                if ((ballCoords.left > a.left) && (ballCoords.top > a.top) &&
                    (ballCoords.left < a.right) && (ballCoords.top < a.bottom))
                {
                    targets.removeAt(i)
                    score = score+1
                    var scores = MainActivity.getInstance().findViewById<TextView>(R.id.score)
                    scores.setText(score.toString())
                    if (targets.size <= 1)
                    {
                        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this.context)
                        dialogBuilder.setTitle("Success")
                        dialogBuilder.setMessage("Congratulation!!")
                        dialogBuilder.setMessage("Would you like to play again?")
                        var handler = DiaHandler()
                        dialogBuilder.setPositiveButton("OK", handler)
                        val dialog = dialogBuilder.create()
                        dialog.show()
                    }
                }
            }
        }
    }
    inner class DiaHandler : DialogInterface.OnClickListener
    {
        override fun onClick(dialog: DialogInterface?, which: Int) {
            if (which == DialogInterface.BUTTON_POSITIVE)
            {
                println("ok")
                score = 0
                shots = 0
                var scores = MainActivity.getInstance().findViewById<TextView>(R.id.score)
                scores.setText(score.toString())
                var shot = MainActivity.getInstance().findViewById<TextView>(R.id.shot)
                shot.setText(shots.toString())
                for (i in 0..6) {
                    for (j in 0..6) {
                        bugCoords.left = (0.45 * width + j * 0.05 * width).toInt()
                        bugCoords.top = (0.08 * height + i * 0.1 * height).toInt()
                        bugCoords.right = (bugCoords.left + 0.05 * width).toInt()
                        bugCoords.bottom = (bugCoords.top + 0.1 * height).toInt()
                        var imageView = ImageView(MainActivity.getInstance())
                        imageView.setImageResource(R.drawable.untouched)
                        var drawable = imageView.getDrawable()
                        drawable.setBounds(bugCoords.left, bugCoords.top, bugCoords.right, bugCoords.bottom)
                        targets.add(drawable)
                    }
                }
                invalidate()
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        var width = this.getWidth()
        var height = this.getHeight()

        var handler = Handler()
        var angle = MainActivity.getInstance().findViewById<SeekBar>(R.id.angle)
        angle.setOnSeekBarChangeListener(handler)
        var handler2 = Handler1()
        var velocity = MainActivity.getInstance().findViewById<SeekBar>(R.id.velocity)
        velocity.setOnSeekBarChangeListener(handler2)
        if ((width < 600) && (height < 400))
        {
            for (i in 0..6) {
                for (j in 0..6) {
                    bugCoords.left = (0.18 * width + j * 0.05 * width).toInt()
                    bugCoords.top = (0.08 * height + i * 0.083 * height).toInt()
                    bugCoords.right = (bugCoords.left + 0.05 * width).toInt()
                    bugCoords.bottom = (bugCoords.top + 0.083 * height).toInt()
                    var imageView = ImageView(MainActivity.getInstance())
                    imageView.setImageResource(R.drawable.untouched)
                    var drawable = imageView.getDrawable()
                    drawable.setBounds(bugCoords.left, bugCoords.top, bugCoords.right, bugCoords.bottom)
                    targets.add(drawable)
                }
            }
            var angle1 = MainActivity.getInstance().findViewById<TextView>(R.id.degree).getText()
            if (angle1 == "0")
            {
                x1 = (width * 0.025).toFloat()
                y1 = (height * 0.6).toFloat()
                x2 = (width * 0.025).toFloat()
                y2 = (height * 0.7).toFloat()
                println("shot the width: " + x1)
                println("shit the height: " + y1)
                println("shot the width: " + x2)
                println("shit the height: " + y2)
            }
        }

        else {
            for (i in 0..6) {
                for (j in 0..6) {
                    bugCoords.left = (0.45 * width + j * 0.05 * width).toInt()
                    bugCoords.top = (0.08 * height + i * 0.1 * height).toInt()
                    bugCoords.right = (bugCoords.left + 0.05 * width).toInt()
                    bugCoords.bottom = (bugCoords.top + 0.1 * height).toInt()
                    var imageView = ImageView(MainActivity.getInstance())
                    imageView.setImageResource(R.drawable.untouched)
                    var drawable = imageView.getDrawable()
                    drawable.setBounds(
                        bugCoords.left,
                        bugCoords.top,
                        bugCoords.right,
                        bugCoords.bottom
                    )
                    targets.add(drawable)
                }
            }
            var angle1 = MainActivity.getInstance().findViewById<TextView>(R.id.degree).getText()
            if (angle1 == "0") {
                x1 = (width * 0.034).toFloat()
                y1 = (height * 0.81).toFloat()
                x2 = (width * 0.034).toFloat()
                y2 = (height * 0.885).toFloat()
                println("shot the width: " + width * 0.034)
                println("shit the height: " + height * 0.81)
            }
        }



        var button = MainActivity.getInstance().findViewById<Button>(R.id.button)
        button.setOnClickListener(handler)

        var timerTask = TimerObject()
        timer.schedule(timerTask, 0, 100)
    }

    inner class Handler : SeekBar.OnSeekBarChangeListener, OnClickListener {
        override fun onProgressChanged(seekBar: SeekBar?, process: Int, fromUser: Boolean) {
            var myView = MainActivity.getInstance().findViewById<MyView>(R.id.myView)
            var width = myView.getWidth()
            var height = myView.getHeight()
            var degree = MainActivity.getInstance().findViewById<TextView>(R.id.degree)
            var angle = process.toString()
            degree.setText(angle)

            if (process != 0) {
                start = true
                var po = (90 - process).toDouble()
                var vary = (height * 0.885) - (height * 0.81)
                var co = Math.cos(Math.toRadians(po))
                var si = Math.sin(Math.toRadians(po))
                if ((width < 600) && (height < 400)) {
                    vary = (height * 0.7) - (height * 0.6)
                    x1 = (co * vary + (width * 0.02)).toFloat()
                    y1 = ((height * 0.7) - si * vary).toFloat()
                }

                else {
                    x1 = (co * vary + (width * 0.034)).toFloat()
                    y1 = ((height * 0.885) - si * vary).toFloat()
                }
                path.reset()
                ballCoords.top = (y1 - width * 0.01).toInt()
                ballCoords.left = (x1).toInt()
                ballCoords.right = (ballCoords.left + 0.015 * width).toInt()
                ballCoords.bottom = (ballCoords.top + 0.03 * height).toInt()
                ball1?.setBounds(ballCoords.left, ballCoords.top,ballCoords.right, ballCoords.bottom)
                invalidate()
            }
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {
        }

        override fun onStopTrackingTouch(seekBar: SeekBar?) {
        }

        override fun onClick(v: View?) {
            var text = (v as Button).getText()
            if (text == "FIRE") {
                start = false
                fire = false
                second = 0
                shots = shots+1
                if (shots != 0) {
                    var shot = MainActivity.getInstance().findViewById<TextView>(R.id.shot)
                    shot.setText(shots.toString())
                }
                ballCoords.top = (y1 - width*0.01).toInt()
                ballCoords.left = (x1).toInt()
                var imageView = ImageView(MainActivity.getInstance())
                imageView.setImageResource(R.drawable.cannon_ball)
                var drawable = imageView.getDrawable()
                ballCoords.right = (ballCoords.left + 0.015 * width).toInt()
                ballCoords.bottom = (ballCoords.top + 0.03 * height).toInt()
                ball1?.setBounds(ballCoords.left, ballCoords.top,ballCoords.right, ballCoords.bottom)
                ball1 = drawable!!
                invalidate()
            }
        }
    }

    inner class TimerObject : TimerTask()
    {
        override fun run()
        {
            var helper = HelperThread()
            MainActivity.getInstance().runOnUiThread(helper)
        }
    }

    inner class HelperThread : Runnable
    {
        override fun run()
        {
            this@MyView.update()
        }
    }

    inner class Handler1 : SeekBar.OnSeekBarChangeListener
    {
        override fun onProgressChanged(seekBar: SeekBar?, process: Int, fromUser: Boolean)
        {
            var degree = MainActivity.getInstance().findViewById<TextView>(R.id.speed)
            var angle = process.toString()
            degree.setText(angle)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?)
        {
        }

        override fun onStopTrackingTouch(seekBar: SeekBar?)
        {
        }
    }

}

