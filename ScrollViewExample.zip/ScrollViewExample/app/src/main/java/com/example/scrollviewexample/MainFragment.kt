package com.example.scrollviewexample

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Space
import android.view.View.*
import androidx.navigation.Navigation

class ButtonHandler : OnClickListener
{
    override fun onClick(p0: View?) {
        var navController = Navigation.findNavController(MainFragment.getInstance().requireView())

        navController.navigate(R.id.mainToSecond, null)

    }
}

class MainFragment : Fragment() {

    companion object
    {
        private var instance : MainFragment? = null
        public fun getInstance() : MainFragment
        {
            return instance!!
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var space : Space
        for ( i in 0..15)
        {
            var button1 = inflate(MainActivity.getInstance(), R.layout.button, null) as Button
            var text = "Button " + 1
            button1.setText(text)

            var handler = ButtonHandler()
            button1.setOnClickListener(handler)

            var linearLayout = MainActivity.getInstance().findViewById<LinearLayout>(R.id.linearLayout)
            linearLayout.addView(button1)

            var space = Space(MainActivity.getInstance())
            space.minimumHeight = 15

            linearLayout.addView(space)
        }
    }

}