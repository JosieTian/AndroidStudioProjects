package com.example.scrollviewexample

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebResourceResponse
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.graphics.Bitmap

class Delegate : WebViewClient()
{
    override fun onPageStarted(view:WebView?, url:String?, favicon:Bitmap?)
    {
        super.onPageStarted(view, url, favicon)
        println("started")
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
    }

    override fun onReceivedError(
        view: WebView?,
        request: WebResourceRequest?,
        error: WebResourceError?
    ) {
        println(error?.description)
    }

    override fun onReceivedHttpError(
        view: WebView?,
        request: WebResourceRequest?,
        errorResponse: WebResourceResponse?
    ) {
        println(errorResponse?.data)
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        println(error?.primaryError)
    }
}

class AudioFragment : Fragment() {

    companion object
    {
        private var instance : AudioFragment? = null
        public fun getInstance() : AudioFragment
        {
            return instance!!
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_audio, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var webview = MainActivity.getInstance().findViewById<WebView>(R.id.webview)
        val settings = webview.getSettings()

        //add the settings
        webview.webViewClient = Delegate()

        //this will allow the tracing of links
        webview.getSettings()?.setJavaScriptEnabled(true);
        webview.getSettings()?.setJavaScriptCanOpenWindowsAutomatically(true);

        //extract out the arguments to set the URL

        //load the URL
        webview?.loadUrl("http://playerservices.streamtheworld.com/api/livestream-redirect/KLALFM.mp3")
    }

}