package com.example.app3

import java.io.Serializable

class Channel :Serializable
{
    private var name : String = ""
    private var url : String = ""
    public fun getName() : String
    {
        return name
    }
    public fun setName(name : String)
    {
        this.name = name
    }
    public fun getUrl() : String
    {
        return url
    }
    public fun setUrl(url : String)
    {
        this.url = url
    }
}