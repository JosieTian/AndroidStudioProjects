package com.example.app3

import android.graphics.Bitmap
import android.net.http.SslError
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.*

class AudioFragment : Fragment() {

    private var channel : Channel? = null
    private var name : String? = null
    private var url : String? = null
    companion object
    {
        private var instance : AudioFragment? = null
        public fun getInstance() : AudioFragment
        {
            return instance!!
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_audio, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Channels")
        var webview = MainActivity.getInstance().findViewById<WebView>(R.id.webview)

        var arguments = this.getArguments()
        channel = arguments?.getSerializable("Channel") as Channel
        name = channel?.getName()
        url = channel?.getUrl()

        webview?.getSettings()?.setJavaScriptEnabled(true);
        webview?.getSettings()?.setJavaScriptCanOpenWindowsAutomatically(true);
        webview?.loadUrl(url!!)
    }
}