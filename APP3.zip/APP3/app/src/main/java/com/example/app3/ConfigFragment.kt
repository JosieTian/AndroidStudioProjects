package com.example.app3

import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.text.Editable
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.text.TextWatcher
import androidx.appcompat.app.AlertDialog
import android.content.DialogInterface.*
import android.view.View.*
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.Navigation


class ConfigFragment : Fragment() {

    private var submit : Unit? = null

    companion object
    {

        private var instance : ConfigFragment? = null
        public fun getInstance() : ConfigFragment
        {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_config, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Config")
        var handler = Handler()
        var res = MainActivity.getInstance().findViewById<Button?>(R.id.config_button)
        submit = res?.setOnClickListener(handler)
        println(submit)
    }
}

class Handler : View.OnClickListener {
    override public fun onClick(view: View) {
        var text = (view as Button).getText()
        if (text == "Submit") {
            println("submit")
            //build alert box
            val dialogBuilder = AlertDialog.Builder(view.context)
            dialogBuilder.setTitle("Success")
            dialogBuilder.setMessage("Channel has been added")

            val fragment = ChannelFragment()
            var handler = DiaHandler()
            dialogBuilder.setPositiveButton("OK",handler)
            val alert1 = dialogBuilder.create()
            alert1.show()

        }
    }
}
class DiaHandler : DialogInterface.OnClickListener
{
    override fun onClick(dialog: DialogInterface?, which: Int)
    {

        if (which == DialogInterface.BUTTON_POSITIVE)
        {
            println("positive")
        }
    }

}