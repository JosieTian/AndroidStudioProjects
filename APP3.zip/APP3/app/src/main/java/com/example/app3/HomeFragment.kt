package com.example.app3

import android.os.Bundle
import android.os.HandlerThread
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView


class HomeFragment : Fragment() {

    companion object {
        private var instance: HomeFragment? = null
        public fun getInstance(): HomeFragment {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Home")

        var quiz = Quiz()
        quiz.start()
    }
}


class Quiz: Thread{

    private var duration: Long = 0
    private var imageView: ImageView? = null

    constructor(){
        duration = 5
        imageView = HomeFragment.getInstance().view?.findViewById(R.id.imageView)
    }

    override public fun run()
    {
        var pics = arrayOf("kabc", "karn", "karnam", "karnfm", "kdxe", "klal", "kurb", "wbap", "wfan", "wkim", "wlac", "wls", "wpgp", "wwtn", "wxyt")
        while(true)
        {
            for (i in 0..pics.size-1) {
                var handler = HandlerThread(pics[i])
                var imageView = MainActivity.getInstance().findViewById<ImageView>(R.id.imageView)
                MainActivity.getInstance().runOnUiThread(handler)
                Thread.sleep(duration * 1000)
            }
        }
    }

    class HandlerThread : Runnable{
        private var pc : String = ""
        constructor(pc : String)
        {
            this.pc = pc
        }
        override fun run()
        {
            var ma = MainActivity.getInstance()
            var imageView = HomeFragment.getInstance().view?.findViewById<ImageView>(R.id.imageView)
            if (imageView != null) {
                var id = MainActivity.getInstance().resources.getIdentifier(pc, "drawable", MainActivity.getInstance().packageName)
                imageView?.setImageResource(id)
            }

        }
    }

}


