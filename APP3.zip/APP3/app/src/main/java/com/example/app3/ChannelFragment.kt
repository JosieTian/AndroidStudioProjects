package com.example.app3

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.View.*
import android.widget.*
import androidx.core.view.allViews
import androidx.navigation.Navigation



class ButtonHandler : OnClickListener {
    override fun onClick(view: View?) {
        var button: Button
        var text: String
        var url3: String
        var navController = Navigation.findNavController(ChannelFragment.getInstance().requireView())

        if (view is Button) {
            button = view
            text = button.text.toString()
            var mm: String = ""
            val bundle = Bundle()
            var channel = Channel()
            if (text == "WBAP" || text == "WFAN" || text == "WLS") {
                mm = "am"
                text = text.toLowerCase()
                url3 = "http://playerservices.streamtheworld.com/api/livestream-redirect/$text$mm.mp3"
                channel.setName(text)
                channel.setUrl(url3)
                bundle.putSerializable("Channel", channel)
            } else if (text == "KDXE" || text == "KLAL" || text == "KURB" || text == "WWTN" || text == "WWYT") {
                mm = "fm"
                text = text.toLowerCase()
                channel.setName(text)
                url3 = "http://playerservices.streamtheworld.com/api/livestream-redirect/$text$mm.mp3"
                channel.setUrl(url3)
                bundle.putSerializable("Channel", channel)
            } else if(text == "KARNAM" || text == "KARNFM")
            {
                text = text.toLowerCase()
                channel.setName(text)
                url3 = "http://playerservices.streamtheworld.com/api/livestream-redirect/$text$mm.mp3"
                channel.setUrl(url3)
                bundle.putSerializable("Channel", channel)
            }
            else
            {
                var b = ChannelFragment.getUrl()
                var a = ChannelFragment.getName()
                for (i in 0..a.size-1) {
                    if (text == a[i] ) {
                        channel.setUrl(b[i])
                    }
                }
                text = text.toLowerCase()
                channel.setName(text)
                bundle.putSerializable("Channel", channel)
            }
            navController.navigate(R.id.mainToSecond, bundle)
        }
    }
}

class ChannelFragment : Fragment() {

    companion object
    {
        private var name6 : String? = null
        private var url6 : String? = null
        private var namelist = ArrayList<String>()
        private var urllist = ArrayList<String>()
        private var instance : ChannelFragment? = null
        private var name = arrayListOf("KABC", "KARNAM", "KARNFM", "KDXE", "KLAL", "KURB", "WBAP", "WFAN", "WLS", "WWTN", "WXYT")

        public fun getName() : ArrayList<String>{
            return namelist
        }
        public fun getUrl() : ArrayList<String>{
            return urllist
        }

        public fun getInstance() : ChannelFragment
        {
            return instance!!
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_channel, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        MainActivity.getInstance().getSupportActionBar()?.setTitle("Channels")

        var name1 = MainActivity.getInstance().findViewById<EditText>(R.id.config_name)
        var url2 = MainActivity.getInstance().findViewById<EditText>(R.id.config_url)

        if( name1 != null)
        {
            name6 = name1.getText().toString()
            namelist.add(name6!!)
        }
        if (url2 != null)
        {
            url6 = url2.getText().toString()
            urllist.add(url6!!)
        }

        //this probably is not the best solution
        if (name1 != null) {
            if (namelist.size > 0) {
                name.add(namelist[namelist.size - 1])
            }
        }
        else
        {
            name = name
        }

        for (i in 0..name.size-1)
        {
            var bt1 = inflate(MainActivity.getInstance(), R.layout.buttom, null) as Button
            bt1.setText(name[i])

            var handler = ButtonHandler()
            bt1.setOnClickListener(handler)

            var linearLayout = MainActivity.getInstance().findViewById<LinearLayout>(R.id.linearLayout)
            linearLayout.addView(bt1)

            var space = Space(MainActivity.getInstance())
            space.minimumHeight = 15

            linearLayout.addView(space)

        }
    }
}
