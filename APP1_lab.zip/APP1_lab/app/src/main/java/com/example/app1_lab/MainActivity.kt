package com.example.app1_lab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.HandlerThread
import android.widget.ImageView
import android.widget.TextView
import kotlin.random.Random


class Quiz: Thread{

    private var duration: Long = 0
    private var noFlags = 0
    private var count: Int = 1
    private var imageView: ImageView? = null
    private var textView: TextView? = null

    constructor(){
        duration = 5
        noFlags = 10
        imageView = MainActivity.getInstance().findViewById(R.id.imageView)
        textView = MainActivity.getInstance().findViewById(R.id.textView)

    }

    override public fun run()
    {
        var count = 0
        var files = arrayOf("afghanistan", "albania", "algeria", "american_samoa", "andorra", "angola", "anguilla", "antigua_and_barbuda", "argentina", "armenia", "aruba", "australia", "austria", "azerbaijan", "bahamas", "bahrain", "bangladesh", "barbados", "belarus", "belgium", "belize", "benin", "bermuda", "bhutan", "bolivia", "bosnia", "botswana", "brazil", "british_virgin_islands", "brunei", "bulgaria", "burkina_faso", "burundi", "cambodia", "cameroon", "canada", "cape_verde", "cayman_islands", "central_african_republic", "chad", "chile", "china", "christmas_island", "colombia", "comoros", "cook_islands", "costa_rica", "croatia", "cuba", "cyprus", "cyprus_northern", "czech_republic", "cte_divoire", "democratic_republic_of_the_congo", "denmark", "djibouti", "dominica", "dominican_republic", "ecuador", "egypt", "el_salvador", "equatorial_guinea", "eritrea", "estonia", "ethiopia", "falkland_islands", "faroe_islands", "fiji", "finland", "france", "french_polynesia", "gabon", "gambia", "georgia", "germany", "ghana", "gibraltar", "greece", "greenland", "grenada", "guam", "guatemala", "guinea", "guinea_bissau", "guyana", "haiti", "honduras", "hong_kong", "hungary", "iceland", "india", "indonesia", "iran", "iraq", "ireland", "israel", "italy", "jamaica", "japan", "jordan", "kazakhstan", "kenya", "kiribati", "kuwait", "kyrgyzstan", "laos", "latvia", "lebanon", "lesotho", "liberia", "libya", "liechtenstein", "lithuania", "luxembourg", "macao", "macedonia", "madagascar", "malawi", "malaysia", "maldives", "mali", "malta", "marshall_islands", "martinique", "mauritania", "mauritius", "mexico", "micronesia", "moldova", "monaco", "mongolia", "montserrat", "morocco", "mozambique", "myanmar", "namibia", "nauru", "nepal", "netherlands", "netherlands_antilles", "new_zealand", "nicaragua", "niger", "nigeria", "niue", "norfolk_island", "north_korea", "norway", "oman", "pakistan", "palau", "panama", "papua_new_guinea", "paraguay", "peru", "philippines", "pitcairn_islands", "poland", "portugal", "puerto_rico", "qatar", "republic_of_the_congo", "romania", "russian_federation", "rwanda", "saint_kitts_and_nevis", "saint_lucia", "saint_pierre", "saint_vicent_and_the_grenadines", "samoa", "san_marino", "sao_tom_and_prncipe", "saudi_arabia", "senegal", "serbia_and_montenegro", "seychelles", "sierra_leone", "singapore", "slovakia", "slovenia", "soloman_islands", "somalia", "south_africa", "south_georgia", "south_korea", "soviet_union", "spain", "sri_lanka", "sudan", "suriname", "swaziland", "sweden", "switzerland", "syria", "taiwan", "tajikistan", "tanzania", "thailand", "tibet", "timor-leste", "togo", "tonga", "trinidad_and_tobago", "tunisia", "turkey", "turkmenistan", "turks_and_caicos_islands", "tuvalu", "uae", "uganda", "ukraine", "united_kingdom", "united_states_of_america", "uruguay", "us_virgin_islands", "uzbekistan", "vanuatu", "vatican_city", "venezuela", "vietnam", "wallis_and_futuna", "yemen", "zambia", "zimbabwe")
        var captions = arrayOf("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia", "Botswana", "Brazil", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Colombia", "Comoros", "Cook Islands", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Cyprus Northern", "Czech Republic", "Cte dIvoire", "Democratic Republic of the Congo", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Polynesia", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guam", "Guatemala", "Guinea", "Guinea Bissau", "Guyana", "Haiti", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "North Korea", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn Islands", "Poland", "Portugal", "Puerto Rico", "Qatar", "Republic of the Congo", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Pierre", "Saint Vicent and the Grenadines", "Samoa", "San Marino", "Sao Tom and Prncipe", "Saudi Arabia", "Senegal", "Serbia and Montenegro", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Soloman Islands", "Somalia", "South Africa", "South Georgia", "South Korea", "Soviet Union", "Spain", "Sri Lanka", "Sudan", "Suriname", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Tibet", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "UAE", "Uganda", "Ukraine", "United Kingdom", "United States of America", "Uruguay", "US Virgin Islands", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Wallis and Futuna", "Yemen", "Zambia", "Zimbabwe")
        var ques = "What Flag is This?"
        var rand = listOf<Int>()

        for (i in 1..10)
        {
            var rnds = (0..223).random()
            rand = rand + rnds
        }

        while(true)
        {
            for (i in 0..9) {
                var handler = HandlerThread(files[rand[i]], ques)
                MainActivity.getInstance().runOnUiThread(handler)
                Thread.sleep(duration * 1000)
                handler = HandlerThread(files[rand[i]], captions[rand[i]])
                MainActivity.getInstance().runOnUiThread(handler)
                Thread.sleep(duration * 1000)
                count++
            }
        }
    }

    class HandlerThread : Runnable
    {
        private var fn : String = ""
        private var caption : String = ""

        constructor(fn : String, caption : String)
        {
            this.fn = fn
            this.caption = caption

        }
        override fun run()
        {
            var imageView = MainActivity.getInstance().findViewById<ImageView>(R.id.imageView)
            var textView = MainActivity.getInstance().findViewById<TextView>(R.id.textView)
            textView.setText(caption)

            var id = MainActivity.getInstance().resources.getIdentifier(fn, "drawable", MainActivity.getInstance().packageName)
            imageView.setImageResource(id)
        }
    }
}

class MainActivity : AppCompatActivity() {

    companion object
    {
        private var instance : MainActivity? = null
        public fun getInstance() : MainActivity
        {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        instance=this
        var quiz = Quiz()
        quiz.start()
    }
}