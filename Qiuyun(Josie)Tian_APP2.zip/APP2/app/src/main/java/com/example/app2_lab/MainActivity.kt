package com.example.app2_lab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.content.DialogInterface
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import androidx.appcompat.app.AlertDialog
import android.content.DialogInterface.*
import android.content.pm.ActivityInfo
import android.view.View
import android.widget.SeekBar.*
import android.widget.CompoundButton.*
import android.view.View.*
import android.webkit.WebView
import android.widget.*

fun isNetworkAvailable(context: Context): Boolean
{
    var result = false
    (context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            result = isCapableNetwork(this,this.activeNetwork)
        } else {
            val networkInfos = this.allNetworks
            for (tempNetworkInfo in networkInfos)
            {
                if(isCapableNetwork(this,tempNetworkInfo))
                    result =  true
            }
        }
    }
    return result
}

fun isCapableNetwork(cm: ConnectivityManager,network: Network?): Boolean{
    cm.getNetworkCapabilities(network)?.also {
        if (it.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return true
        } else if (it.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            return true
        }
    }
    return false
}



//one class-multiple listener-multiple widgets
class Handler : DialogInterface.OnClickListener, OnSeekBarChangeListener, OnCheckedChangeListener, View.OnClickListener
{

    override fun onClick(dialog: DialogInterface?, which: Int)
    {
        if (which == DialogInterface.BUTTON_NEGATIVE)
        {
            println("negative")
        }
        else if (which == DialogInterface.BUTTON_POSITIVE)
        {
            println("positive")
        }
    }

    override fun onClick(v: View?) {
        var text = (v as Button).getText()
        if (text == "Play"){
            var name1 = MainActivity.getInstance().findViewById<TextView>(R.id.textView).getText()
            var mm = MainActivity.getInstance().findViewById<Button>(R.id.band).getText()
            var webView = MainActivity.getInstance().findViewById<WebView>(R.id.screen)
            var url = "http://playerservices.streamtheworld.com/api/livestream-redirect/$name1$mm.mp3"
            webView?.getSettings()?.setJavaScriptEnabled(true);
            webView?.getSettings()?.setJavaScriptCanOpenWindowsAutomatically(true);
            webView?.loadUrl(url)
        }
    }

    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
        //slider is the value(text)
        var bar = MainActivity.getInstance().findViewById<SeekBar>(R.id.seekBar)
        var mm = MainActivity.getInstance().findViewById<Button>(R.id.band).getText()
        var slider = MainActivity.getInstance().findViewById<ImageView>(R.id.image)
        var name = MainActivity.getInstance().findViewById<TextView>(R.id.textView)
        var imgResId = R.drawable.launch
        var imgTet = ""

        //progress is the number of seekbar you click
        var num = progress
        if (mm == "AM") {
            if (num in (26..31)) {
                imgResId = R.drawable.wfan
                imgTet = "WFAN"
            } else if (num in (38..41)) {
                imgResId = R.drawable.kabc
                imgTet = "KABC"
            } else if (num in (42..45)) {
                imgResId = R.drawable.wbap
                imgTet = "WBAP"
            } else if (num in (47..49)) {
                imgResId = R.drawable.wls
                imgTet = "WLS"
            } else if (num in (50..54)) {
                imgResId = R.drawable.karnam
                imgTet = "KARN"
            }
        }

        else if (mm == "FM") {
            if (num in (42..44)) {
                imgResId = R.drawable.wxyt
                imgTet = "WXYT"
            } else if (num in (48..50)) {
                imgResId = R.drawable.kurb
                imgTet = "KURB"
            } else if (num in (51..53)) {
                imgResId = R.drawable.wkim
                imgTet = "WKIM"
            } else if (num in (56..58)) {
                imgResId = R.drawable.wwtn
                imgTet = "WWTN"
            } else if (num in (63..65)) {
                imgResId = R.drawable.kdxe
                imgTet = "KDXE"
            } else if (num in (67..69)) {
                imgResId = R.drawable.karnam
                imgTet = "KARN"
            } else if (num in (86..89)) {
                imgResId = R.drawable.klal
                imgTet = "KLAL"
            }
        }
            slider.setImageResource(imgResId)
            name.setText(imgTet)
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {
    }

    override fun onStopTrackingTouch(seekBar: SeekBar?) {
    }

    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        var text = buttonView?.getText()
        if (text == "AM")
        {
            var bar = MainActivity.getInstance().findViewById<SeekBar>(R.id.seekBar)
            buttonView?.setText("FM")
        }
        else
        {
            var bar = MainActivity.getInstance().findViewById<SeekBar>(R.id.seekBar)
            buttonView?.setText("AM")
        }
    }
}

    class MainActivity : AppCompatActivity() {

        private var webView : WebView? = null
        companion object {
            private var instance: MainActivity? = null

            public fun getInstance(): MainActivity {
                return instance!!
            }
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            var handler = Handler()
            var res = isNetworkAvailable(this)
            val dialogBuilder = AlertDialog.Builder(this)
            dialogBuilder.setTitle("Failure!")
            dialogBuilder.setMessage("Not Connected To Internet")
            dialogBuilder.setPositiveButton("OK",handler)
            val alert1 = dialogBuilder.create()
            if (res == false) {
                alert1.setTitle("No Internet")
                alert1.show()
            }

            //hide the apptitlebar
            supportActionBar?.hide()
            instance = this
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

            var play = findViewById<Button>(R.id.play)
            var slider = findViewById<SeekBar>(R.id.seekBar)
            var band = findViewById<CompoundButton>(R.id.band)

            play.setOnClickListener(handler)
            slider.setOnSeekBarChangeListener(handler)
            band.setOnCheckedChangeListener(handler)
        }
    }
