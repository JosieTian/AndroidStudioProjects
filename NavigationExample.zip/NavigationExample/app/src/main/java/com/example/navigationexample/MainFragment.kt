package com.example.navigationexample

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.View.*
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.Navigation

class Handler : OnClickListener
{
    override public fun onClick(view: View) {
        println(view)
        var button : Button
        var text : String
        var navController = Navigation.findNavController(MainFragment.getInstance().requireView())

        if (view is Button)
        {
            button = view
            text = button.text.toString()
            if (text == "Jim")
            {
                val bundle = Bundle()
                var person = Person()
                person.setRoom("123")
                person.setName("Jim")
                person.setPic("pic1")
                person.setTitle("Asst Professor")
                bundle.putSerializable("Person", person)
                bundle.putInt("number", 1)
                navController.navigate(R.id.mainToSecond, bundle)
            }
            else if(text == "Mary")
            {
                val bundle = Bundle()
                var person = Person()
                person.setRoom("124")
                person.setName("Mary")
                person.setPic("pic2")
                person.setTitle("Lecturer")
                bundle.putSerializable("Person", person)
                //navController.navigate(R.id.mainToFourth, bundle)
            }
        }
    }
}


class MainFragment : Fragment() {

    private var jim : Button? =null
    companion object
    {
        private var instance : MainFragment? = null
        public fun getInstance() : MainFragment
        {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        MainActivity.getInstance().getSupportActionBar()?.setTitle("Contacts")
        //Get the bundle
        var handler = Handler()

        jim = MainActivity.getInstance().findViewById<Button>(R.id.jim)
        jim?.setOnClickListener(handler)

    }



}