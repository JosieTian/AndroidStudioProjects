package com.example.navigationexample

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView


class ThirdFragment : Fragment() {
    private var person : Person? = null
    private var name : EditText? = null
    private var textView : TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_third, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //get the bundles
        var arguments = this.getArguments()
        person = arguments?.getSerializable("Person") as Person
        name = MainActivity.getInstance().findViewById<EditText>(R.id.name)
        textView = MainActivity.getInstance().findViewById<TextView>(R.id.textview)

        name?.setText(person?.getName())
        textView?.setText(person?.getName() + "Info")
    }
}