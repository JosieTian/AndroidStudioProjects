package com.example.navigationexample

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.View.*
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.Navigation

class ModifyHandler : OnClickListener
{
    private var person : Person? = null
    constructor(person : Person)
    {
        this.person = person
    }

    override fun onClick(V: View?) {
        var navController = Navigation.findNavController(SecondFragment.getInstance().requireView())
        val bundle = Bundle()
        bundle.putSerializable("Person", person)
        navController.navigate(R.id.secondToThird, bundle)
    }
}

class SecondFragment : Fragment() {

    private var pic : ImageView? = null
    private var name : TextView? = null
    private var title : TextView? = null
    private var modify : Button? = null
    private var person : Person? = null

    companion object
    {
        private var instance : SecondFragment? = null
        public fun getInstance() : SecondFragment
        {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //get the bundle
        var arguments = this.getArguments()
        person = arguments?.getSerializable("Person") as Person
        var num = arguments.getInt("number")

        //set the info
        pic = MainActivity.getInstance().findViewById(R.id.imageView)
        //pic?.setImageResource(id)
        name = MainActivity.getInstance().findViewById<TextView>(R.id.nameValue)
        //name?.setText(person?.getName())
        title = MainActivity.getInstance().findViewById(R.id.titleValue)
        title?.setText(person?.getTitle())
        var modify = MainActivity.getInstance().findViewById<Button>(R.id.modify)
        val id = MainActivity.getInstance().resources.getIdentifier(person?.getPic(),"drawable", MainActivity.getInstance().packageName)
        pic?.setImageResource(id)
        name?.setText(person?.getName())

        var handler = ModifyHandler(person!!)
        modify.setOnClickListener(handler)


    }


}