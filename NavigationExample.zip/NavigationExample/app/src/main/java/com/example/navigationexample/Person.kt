package com.example.navigationexample

import java.io.Serializable

class Person : Serializable
{
    private var name : String = ""
    private var pic : String = ""
    private var room : String = ""
    private var title : String = ""
    public fun getTitle() : String
    {
        return title
    }
    public fun setTitle(title : String)
    {
        this.title = title
    }
    public fun setName(name : String)
    {
        this.name = name
    }
    public fun getName() : String
    {
        return name
    }
    public fun setPic(pic : String)
    {
        this.pic = pic
    }
    public fun getPic() : String
    {
        return pic
    }
    public fun getRoom() : String
    {
        return room
    }
    public fun setRoom(room : String)
    {
        this.room = room
    }

}