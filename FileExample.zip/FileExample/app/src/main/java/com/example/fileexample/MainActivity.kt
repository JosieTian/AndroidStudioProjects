package com.example.fileexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.io.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var is1 = this.getAssets().open("people1.txt")
        var reader1 = BufferedReader(InputStreamReader(is1))
        var lines1 = reader1.readLines()
        println(lines1)

        var arraylines1 = lines1.toTypedArray()
        var allData1 = arrayOf<Array<String>>()

        for (i in 0..arraylines1.size-1)
        {
            var array1 = arraylines1[i].split(",")
            allData1 += array1.toTypedArray()
        }

        reader1.close()

        //write into files
        var fileWrite = File(this.filesDir, "data.txt")
        fileWrite.createNewFile()

        var out_file = PrintStream(fileWrite)
        //create a 2-D array of data to write into the file
        var array = arrayOf<Array<String>>(arrayOf("Josie Tian", "long hair", "love computer science"), arrayOf("Steven Simmermon", "short hair", "love music"), arrayOf("Huahua Tian", "grey hair", "love sleeping"))

        for (i in 0..array.size-1)
        {
            var str : String = ""
            for (j in 0..(array[i].size-1))
            {
                str += array[i][j]
                if (j < array[i].size-1)
                    str += ","
            }
            out_file.println(str)
        }
        out_file.close()

        var reader = fileWrite.bufferedReader()
        var lines = reader.readLines()
        var arrayLines = lines.toTypedArray()
        var allData = arrayOf<Array<String>>()

        for (i in 0..arrayLines.size-1)
        {
            var array1 = arrayLines[i].split(",")
            allData += array1.toTypedArray()
        }
        reader.close()
    }

}