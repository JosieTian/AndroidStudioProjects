package com.example.qiuyunapp6

import android.content.Context
import android.graphics.Canvas
import android.graphics.Point
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import android.view.View.*
import android.widget.ImageView
import android.graphics.*
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.TranslateAnimation
import android.widget.EditText
import android.widget.TextView
import com.example.qiuyunapp6.MainActivity
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.abs

class MyView : View {
    private var timer = Timer()
    private var frame: Drawable? = null
    private var lionTouched = false
    private var cobraTouched = false
    private var rabitTouched = false
    private var lion0: ImageView? = null
    private var cobra: ImageView? = null
    private var rabit: ImageView? = null
    private var lionCoords: Rect = Rect(0, 0, 0, 0)
    private var cobraCoords: Rect = Rect(0, 0, 0, 0)
    private var rabitCoords: Rect = Rect(0, 0, 0, 0)
    private var frameCoords: Rect = Rect(0, 0, 0, 0)
    private var lionstart: Boolean = false
    private var cobrastart: Boolean = false
    private var rabitstart: Boolean = false
    private var lionready: Boolean = false
    private var cobraready: Boolean = false
    private var rabitready: Boolean = false
    private var liongo : Boolean = false
    private var lionchange :Boolean =false
    private var ready: Boolean = false
    private var phonemove : Boolean = false
    private var second : Int = -1
    private var score : Int = 0
    private var playing : Int = 0
    private var repeat : Boolean = false
    private var phone: ImageView? = null
    private var dell : Int = 0
    private var dlle : Int = 0

    companion object {
        private var instance: MyView? = null
        public fun getInstance(): MyView {
            return instance!!
        }
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        instance = this
    }

    public fun setLionCoords(ux: Int, uy: Int, lx: Int, ly: Int) {
        this.lionCoords.set(ux, uy, lx, ly)
    }

    public fun getLionCoords(): Rect {
        return lionCoords
    }

    public fun setCobraCoords(ux: Int, uy: Int, lx: Int, ly: Int) {
        this.cobraCoords.set(ux, uy, lx, ly)
    }

    public fun getCobraCoords(): Rect {
        return cobraCoords
    }

    public fun setRabitCoords(ux: Int, uy: Int, lx: Int, ly: Int) {
        this.rabitCoords.set(ux, uy, lx, ly)
    }

    public fun getRabitCoords(): Rect {
        return rabitCoords
    }

    public fun setFrameCoords(ux: Int, uy: Int, lx: Int, ly: Int) {
        this.frameCoords.set(ux, uy, lx, ly)
    }

    public fun getFrameCoords(): Rect {
        return frameCoords
    }

    public fun update() {
        if (lionchange) {
            if (second <= 3) {
                second += 1
            } else {
                second = -1
            }

            if (second == 0)
                lion0!!.setImageResource(R.drawable.lion0)
            else if (second == 1)
                lion0!!.setImageResource(R.drawable.lion1)
            else if (second == 2)
                lion0!!.setImageResource(R.drawable.lion2)
            else if (second == 3)
                lion0!!.setImageResource(R.drawable.lion3)
            invalidate()
        }
    }


    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        frame!!.draw(canvas!!)
        if (lionstart){
            lion0?.setX(lionCoords.left.toFloat())
            lion0?.setY(lionCoords.top.toFloat())
        }
        if (cobrastart) {
            cobra?.setX(cobraCoords.left.toFloat())
            cobra?.setY(cobraCoords.top.toFloat())
        }
        if (rabitstart) {
            rabit?.setX(rabitCoords.left.toFloat())
            rabit?.setY(rabitCoords.top.toFloat())
        }

        if (lion0?.alpha == 0.0f)
        {
            lion0?.alpha = 1.0f
            lion0?.setX(lionCoords.left.toFloat())
            lion0?.setY(lionCoords.top.toFloat())
        }

    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        lion0 = MainActivity.getInstance().findViewById(R.id.lion)
        cobra = MainActivity.getInstance().findViewById(R.id.cobra)
        rabit = MainActivity.getInstance().findViewById(R.id.rabit)
        var width = getWidth()
        var height = getHeight()
        println("this is width  $width,  $height")
        frameCoords.left = (0.12 * width).toInt()
        frameCoords.top = (0.15 * height).toInt()
        frameCoords.right = (0.8 * width).toInt()
        frameCoords.bottom = (0.9 * height).toInt()
        var imageView1 = ImageView(MainActivity.getInstance())
        imageView1.setImageResource(R.drawable.jungleframe)
        frame = imageView1.getDrawable()
        frame?.setBounds(frameCoords.left, frameCoords.top, frameCoords.right, frameCoords.bottom)
        var timerTask = TimerObject()
        timer.schedule(timerTask, 0, 100)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        var x = event.getX()
        var y = event.getY()
        val lionW = lion0?.getWidth()
        val lionH = lion0?.getHeight()
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if ((x > lion0?.left!!) && (x < lion0?.right!!)
                && (y > lion0?.top!!) && (y < lion0?.bottom!!)
            ) {
                lionTouched = true
                lionstart = true
                lionCoords = Rect(lion0?.left!!, lion0?.top!!, lion0?.right!!, lion0?.bottom!!)
            }
            if ((x > cobra?.left!!) && (x < cobra?.right!!)
                && (y > cobra?.top!!) && (y < cobra?.bottom!!)
            ) {
                cobraTouched = true
                cobrastart = true
                cobraCoords = Rect(cobra?.left!!, cobra?.top!!, cobra?.right!!, cobra?.bottom!!)
            }
            if ((x > rabit?.left!!) && (x < rabit?.right!!)
                && (y > rabit?.top!!) && (y < rabit?.bottom!!)
            ) {
                rabitTouched = true
                rabitstart = true
                rabit!!.scaleX = -1.0f
                rabitCoords = Rect(rabit?.left!!, rabit?.top!!, rabit?.right!!, rabit?.bottom!!)
            }
        } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
            if (lionTouched) {
                lionchange = true
                lionCoords.left = x.toInt() - lionW!! / 2
                lionCoords.top = y.toInt() - lionH!! / 2
                lionCoords.right = x.toInt() + lionW!!
                lionCoords.bottom = y.toInt() + lionH!!
                lionCoords = Rect(lionCoords.left, lionCoords.top, lionCoords.right, lionCoords.bottom)
                this.invalidate()
            }
            if (cobraTouched) {
                val lionW = cobra?.getWidth()
                val lionH = cobra?.getHeight()
                cobraCoords.left = x.toInt() - lionW!! / 2
                cobraCoords.top = y.toInt() - lionH!! / 2
                cobraCoords.right = x.toInt() + lionW!!
                cobraCoords.bottom = y.toInt() + lionH!!
                cobraCoords =
                    Rect(cobraCoords.left, cobraCoords.top, cobraCoords.right, cobraCoords.bottom)
                this.invalidate()
            }
            if (rabitTouched) {
                val lionW = rabit?.getWidth()
                val lionH = rabit?.getHeight()
                rabitCoords.left = x.toInt() - lionW!! / 2
                rabitCoords.top = y.toInt() - lionH!! / 2
                rabitCoords.right = x.toInt() + lionW!!
                rabitCoords.bottom = y.toInt() + lionH!!
                rabitCoords =
                    Rect(rabitCoords.left, rabitCoords.top, rabitCoords.right, rabitCoords.bottom)
                this.invalidate()
            }
        } else if (event.getAction() == MotionEvent.ACTION_UP) {
            println("touched up - $x, $y")
            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var fadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
            var congrat = MainActivity.getInstance().findViewById<TextView>(R.id.congrat)
            var random = (0..2).random()
            //var random = 2
            if (random == 0) {
                phone =
                    MainActivity.getInstance().findViewById<ImageView>(R.id.phonelion)
                phone!!.scaleX = -1.0f
            } else if (random == 1) {
                phone =
                    MainActivity.getInstance().findViewById<ImageView>(R.id.phonecobra)
                phone!!.scaleX = -1.0f
            } else if (random == 2) {
                phone =
                    MainActivity.getInstance().findViewById<ImageView>(R.id.phonerabit)
            }
            if (lionTouched) {
                lionchange = false
                lion0!!.setImageResource(R.drawable.lion0)
                lionTouched = false
                println("this is lion : ${lionCoords.left}, ${lionCoords.top}, ${lionCoords.right} , ${lionCoords.bottom}")
               if ((lionCoords.left > frameCoords.left) && (lionCoords.right < frameCoords.right + 100)
                    && (lionCoords.top > frameCoords.top) && (lionCoords.bottom < frameCoords.bottom + 100)
                ) {
                   var animHandler1 = FadeInHandler()
                   fadeIn.setAnimationListener(animHandler1)
                   phone!!.startAnimation(fadeIn)
                   ready = true
                   lionready = true
                   lionCoords.left = 580
                   lionCoords.top = 779
                   lionCoords.right = 895
                   lionCoords.bottom = 1007
                   lionCoords =
                       Rect(lionCoords.left, lionCoords.top, lionCoords.right, lionCoords.bottom)
                   invalidate()

                   if (random == 0) {
                       congrat.setText("Tie!")
                       var animHandler1 = FadeInHandler()
                       fadeIn.setAnimationListener(animHandler1)
                       congrat.startAnimation(fadeIn)
                       var lionfadeOut = AnimationUtils.loadAnimation(
                           MainActivity.getInstance(),
                           R.anim.fade_out
                       )
                       var animHandler2 = FadeOutHandler()
                       fadeOut.setAnimationListener(animHandler2)
                       var lionanimHandler = LionFadeOutHandler()
                       lionfadeOut.setAnimationListener(lionanimHandler)
                       lion0!!.startAnimation(lionfadeOut)
                       phone!!.startAnimation(fadeOut)
                   } else if (random == 1) {
                       score += 1
                       congrat.setText("Cobra defeats Lion -- You Lose!")
                       var animHandler1 = FadeInHandler()
                       fadeIn.setAnimationListener(animHandler1)
                       congrat.startAnimation(fadeIn)
                       var moveAnim = TranslateAnimation(0f, 289.0f, 0f, 0f)
                       moveAnim.duration = 2000
                       moveAnim.fillAfter = true
                       var handler = phonemoveHandler()
                       moveAnim.setAnimationListener(handler)
                       phone!!.startAnimation(moveAnim)
                       var lionanimHandler = LionFadeOutHandler()
                       fadeOut.setAnimationListener(lionanimHandler)
                       lion0!!.startAnimation(fadeOut)
                   } else if (random == 2) {
                       playing += 1
                       congrat.setText("Lion defeats Rabit -- You Win!")
                       var animHandler1 = FadeInHandler()
                       fadeIn.setAnimationListener(animHandler1)
                       congrat.startAnimation(fadeIn)
                       var moveAnim = TranslateAnimation(0f, -289.0f, 0f, 0f)
                       moveAnim.duration = 2000
                       moveAnim.fillAfter = true
                       var handler = lionmoveHandler()
                       moveAnim.setAnimationListener(handler)
                       lion0!!.startAnimation(moveAnim)
                       var animHandler2 = FadeOutHandler()
                       fadeOut.setAnimationListener(animHandler2)
                       phone!!.startAnimation(fadeOut)
                   }

               } else {
                   lionCoords = Rect(lion0?.left!!, lion0?.top!!, lion0?.right!!, lion0?.bottom!!)
                   invalidate()
               }
            }

            if (cobraTouched) {
                cobraTouched = false
                if ((cobraCoords.left > frameCoords.left) && (cobraCoords.right < frameCoords.right + 100)
                    && (cobraCoords.top > frameCoords.top) && (cobraCoords.bottom < frameCoords.bottom + 100)
                ) {
                    var animHandler1 = FadeInHandler()
                    fadeIn.setAnimationListener(animHandler1)
                    phone!!.startAnimation(fadeIn)
                    ready = true
                    cobraready = true
                    cobraCoords.left = 580
                    cobraCoords.top = 779
                    cobraCoords.right = 895
                    cobraCoords.bottom = 1007
                    cobraCoords = Rect(cobraCoords.left, cobraCoords.top, cobraCoords.right, cobraCoords.bottom)
                    invalidate()
                    if (random == 0) {
                        playing += 1
                        congrat.setText("Cobra defeats Lion -- You Win!")
                        var animHandler1 = FadeInHandler()
                        fadeIn.setAnimationListener(animHandler1)
                        congrat.startAnimation(fadeIn)
                        var moveAnim = TranslateAnimation(0f, -289.0f, 0f, 0f)
                        moveAnim.duration = 2000
                        moveAnim.fillAfter = true
                        var handler = cobramoveHandler()
                        moveAnim.setAnimationListener(handler)
                        cobra!!.startAnimation(moveAnim)
                        var animHandler2 = FadeOutHandler()
                        fadeOut.setAnimationListener(animHandler2)
                        phone!!.startAnimation(fadeOut)

                    } else if (random == 1) {
                        congrat.setText("Tie!")
                        var animHandler1 = FadeInHandler()
                        fadeIn.setAnimationListener(animHandler1)
                        congrat.startAnimation(fadeIn)
                        var cobrafadeOut = AnimationUtils.loadAnimation(
                            MainActivity.getInstance(),
                            R.anim.fade_out
                        )
                        var cobraanimHandler = cobraFadeOutHandler()
                        cobrafadeOut.setAnimationListener(cobraanimHandler)
                        cobra!!.startAnimation(cobrafadeOut)
                        phone!!.startAnimation(fadeOut)
                    } else if (random == 2) {
                        score += 1
                        congrat.setText("Rabit Defeat Cobra! -- You Lose!")
                        var animHandler1 = FadeInHandler()
                        fadeIn.setAnimationListener(animHandler1)
                        congrat.startAnimation(fadeIn)
                        var moveAnim = TranslateAnimation(0f, 289.0f, 0f, 0f)
                        moveAnim.duration = 2000
                        moveAnim.fillAfter = true
                        var handler = phonemoveHandler()
                        moveAnim.setAnimationListener(handler)
                        phone!!.startAnimation(moveAnim)
                        var cobraanimHandler = cobraFadeOutHandler()
                        fadeOut.setAnimationListener(cobraanimHandler)
                        cobra!!.startAnimation(fadeOut)
                    }

                } else {
                    cobraCoords =
                        Rect(cobra?.left!!, cobra?.top!!, cobra?.right!!, cobra?.bottom!!)
                    invalidate()
                }
            }
            if (rabitTouched) {
                rabitTouched = false
                if ((rabitCoords.left > frameCoords.left) && (rabitCoords.right < frameCoords.right + 100)
                    && (rabitCoords.top > frameCoords.top) && (rabitCoords.bottom < frameCoords.bottom + 100)
                ) {
                    var animHandler1 = FadeInHandler()
                    fadeIn.setAnimationListener(animHandler1)
                    phone!!.startAnimation(fadeIn)
                    ready = true
                    rabitready = true
                    rabitCoords.left = 580
                    rabitCoords.top = 779
                    rabitCoords.right = 895
                    rabitCoords.bottom = 1007
                    rabitCoords = Rect(rabitCoords.left, rabitCoords.top, rabitCoords.right, rabitCoords.bottom)
                    invalidate()
                    if (random == 0) {
                        score += 1
                        congrat.setText("Lion Defeat Rabit! -- You Lose!")
                        var animHandler1 = FadeInHandler()
                        fadeIn.setAnimationListener(animHandler1)
                        congrat.startAnimation(fadeIn)
                        var moveAnim = TranslateAnimation(0f, 289.0f, 0f, 0f)
                        moveAnim.duration = 2000
                        moveAnim.fillAfter = true
                        var handler = phonemoveHandler()
                        moveAnim.setAnimationListener(handler)
                        phone!!.startAnimation(moveAnim)
                        var rabitanimHandler = rabitFadeOutHandler()
                        fadeOut.setAnimationListener(rabitanimHandler)
                        rabit!!.startAnimation(fadeOut)
                    } else if (random == 1) {
                        playing += 1
                        congrat.setText("Cobra defeats Lion -- You Win!")
                        var animHandler1 = FadeInHandler()
                        fadeIn.setAnimationListener(animHandler1)
                        congrat.startAnimation(fadeIn)
                        var moveAnim = TranslateAnimation(0f, -289.0f, 0f, 0f)
                        moveAnim.duration = 2000
                        moveAnim.fillAfter = true
                        var handler = rabitmoveHandler()
                        moveAnim.setAnimationListener(handler)
                        rabit!!.startAnimation(moveAnim)
                        var animHandler2 = FadeOutHandler()
                        fadeOut.setAnimationListener(animHandler2)
                        phone!!.startAnimation(fadeOut)
                    } else if (random == 2) {
                        congrat.setText("Tie!")
                        var animHandler1 = FadeInHandler()
                        fadeIn.setAnimationListener(animHandler1)
                        congrat.startAnimation(fadeIn)
                        var rabitfadeOut = AnimationUtils.loadAnimation(
                            MainActivity.getInstance(),
                            R.anim.fade_out
                        )
                        var rabitanimHandler = rabitFadeOutHandler()
                        rabitfadeOut.setAnimationListener(rabitanimHandler)
                        var animHandler2 = FadeOutHandler()
                        fadeOut.setAnimationListener(animHandler2)
                        rabit!!.startAnimation(rabitfadeOut)
                        phone!!.startAnimation(fadeOut)
                    }


                } else {
                    rabitCoords = Rect(rabit?.left!!, rabit?.top!!, rabit?.right!!, rabit?.bottom!!)
                    rabit?.scaleX = 1.0f
                    invalidate()
                }

            }
            var player = MainActivity.getInstance().findViewById<TextView>(R.id.player)
            var phoneScore = MainActivity.getInstance().findViewById<TextView>(R.id.phone)
            player.setText(playing.toString())
            phoneScore.setText(score.toString())
            liongo=false
        }
        return true

    }

    inner class TimerObject : TimerTask()
    {
        override fun run()
        {
            var helper = HelperThread()
            MainActivity.getInstance().runOnUiThread(helper)
        }
    }

    inner class HelperThread : Runnable
    {
        override fun run()
        {
            this@MyView.update()
        }
    }
    inner class phonemoveHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }
        override fun onAnimationEnd(animation: Animation?) {

            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler1 = FadeOutHandler()
            fadeOut.setAnimationListener(animHandler1)
            phone?.startAnimation(fadeOut)
            phonemove = true
            var congrat = MainActivity.getInstance().findViewById<TextView>(R.id.congrat)
            congrat.startAnimation(fadeOut)

        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }

    inner class moveHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }
        override fun onAnimationEnd(animation: Animation?) {
        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }
    inner class lionmoveHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }
        override fun onAnimationEnd(animation: Animation?) {
            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler = LionFadeOutHandler()
            fadeOut.setAnimationListener(animHandler)
            lion0?.startAnimation(fadeOut)
            //invalidate()
        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }
    inner class cobramoveHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }
        override fun onAnimationEnd(animation: Animation?) {

            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler = cobraFadeOutHandler()
            fadeOut.setAnimationListener(animHandler)
            cobra?.startAnimation(fadeOut)

        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }
    inner class rabitmoveHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }
        override fun onAnimationEnd(animation: Animation?) {
            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler = rabitFadeOutHandler()
            fadeOut.setAnimationListener(animHandler)
            rabit?.startAnimation(fadeOut)
        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }

    /*********************FadeOutHandler**********************************/
    inner class FadeOutHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }

        override fun onAnimationEnd(animation: Animation?) {
        }

        override fun onAnimationStart(animation: Animation?) {
        }
    }
    /****************************************************************/
    /*********************FadeOutHandler**********************************/
    inner class LionFadeOutHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }

        override fun onAnimationEnd(animation: Animation?) {
            lionCoords = Rect(lion0?.left!!, lion0?.top!!, lion0?.right!!, lion0?.bottom!!)
            var fadeIn =
                AnimationUtils.loadAnimation(
                    MainActivity.getInstance(),
                    R.anim.fade_in
                )
            var animHandler1 = FadeInHandler()
            fadeIn.setAnimationListener(animHandler1)
            lion0?.startAnimation(fadeIn)
            invalidate()
            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler = FadeOutHandler()
            fadeOut.setAnimationListener(animHandler)
            var congrat = MainActivity.getInstance().findViewById<TextView>(R.id.congrat)
            congrat.startAnimation(fadeOut)
        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }
    /****************************************************************/

    /*********************FadeOutHandler**********************************/
    inner class cobraFadeOutHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }

        override fun onAnimationEnd(animation: Animation?) {
            cobraCoords = Rect(cobra?.left!!, cobra?.top!!, cobra?.right!!, cobra?.bottom!!)
            var fadeIn =
                AnimationUtils.loadAnimation(
                    MainActivity.getInstance(),
                    R.anim.fade_in
                )
            var animHandler1 = FadeInHandler()
            fadeIn.setAnimationListener(animHandler1)
            cobra?.startAnimation(fadeIn)
            invalidate()
            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler = FadeOutHandler()
            fadeOut.setAnimationListener(animHandler)
            var congrat = MainActivity.getInstance().findViewById<TextView>(R.id.congrat)
            congrat.startAnimation(fadeOut)
        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }
    /****************************************************************/
    /*********************FadeOutHandler**********************************/
    inner class rabitFadeOutHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
        }

        override fun onAnimationEnd(animation: Animation?) {
            rabitCoords = Rect(rabit?.left!!, rabit?.top!!, rabit?.right!!, rabit?.bottom!!)
            rabit!!.scaleX = 1.0f
            var fadeIn =
                AnimationUtils.loadAnimation(
                    MainActivity.getInstance(),
                    R.anim.fade_in
                )
            var animHandler1 = FadeInHandler()
            fadeIn.setAnimationListener(animHandler1)
            rabit?.startAnimation(fadeIn)
            invalidate()
            var fadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler = FadeOutHandler()
            fadeOut.setAnimationListener(animHandler)
            var congrat = MainActivity.getInstance().findViewById<TextView>(R.id.congrat)
            congrat.startAnimation(fadeOut)
        }
        override fun onAnimationStart(animation: Animation?) {
        }
    }
    /****************************************************************/


    /**************************FadeInHandler**********************************************/
    inner class FadeInHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
            println("repeat")
        }

        override fun onAnimationEnd(animation: Animation?) {
            println("Fade in finshied")

        }

        override fun onAnimationStart(animation: Animation?) {

            println("Fade in start")
        }
    }

    /**********************************************************************************/

}
