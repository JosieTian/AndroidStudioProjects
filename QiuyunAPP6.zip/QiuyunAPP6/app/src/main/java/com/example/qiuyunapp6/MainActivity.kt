package com.example.qiuyunapp6

import android.graphics.Canvas
import android.graphics.Point
import android.graphics.Rect
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private var imageView : ImageView? = null
    private var gone : Boolean = true
    companion object
    {
        private var instance : MainActivity? = null
        public fun getInstance() : MainActivity
        {
            return instance!!
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        instance = this
        supportActionBar?.hide()
        imageView = ImageView(this)
        var text1 = findViewById<TextView>(R.id.textView1)
        var text2 = findViewById<TextView>(R.id.textView2)
        var text3 = findViewById<TextView>(R.id.phone)
        var text4 = findViewById<TextView>(R.id.player)
        var phonelion = findViewById<ImageView>(R.id.phonelion)
        var phonecobra = findViewById<ImageView>(R.id.phonecobra)
        var phonerabit = findViewById<ImageView>(R.id.phonerabit)
        var quickhide = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.quickhide)
        var quickhidehandler = quickHandler()
        quickhide.setAnimationListener((quickhidehandler))
        text1.startAnimation(quickhide)
        text2.startAnimation(quickhide)
        text3.startAnimation(quickhide)
        text4.startAnimation(quickhide)
        phonelion.startAnimation(quickhide)
        phonecobra.startAnimation(quickhide)
        phonerabit.startAnimation(quickhide)
        var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.headeranim)
        var animHandler = FadeOutHandler()
        myFadeOut.setAnimationListener(animHandler)
        var frame = getInstance().findViewById<ImageView>(R.id.title)
        frame.startAnimation(myFadeOut)
    }
    inner class quickHandler : Animation.AnimationListener
    {
        override fun onAnimationRepeat(animation: Animation?)
        {
        }
        override fun onAnimationEnd(animation: Animation?)
        {
        }
        override fun onAnimationStart(animation: Animation?)
        {
        }
    }
    /*********************FadeOutHandler**********************************/
    inner class FadeOutHandler : Animation.AnimationListener
    {
        override fun onAnimationRepeat(animation: Animation?)
        {
        }
        override fun onAnimationEnd(animation: Animation?)
        {
            var frame = getInstance().findViewById<ImageView>(R.id.title)
            frame.visibility= View.GONE
            gone = false
            if (!gone) {
                var fadeIn =
                    AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
                var animHandler1 = FadeInHandler()
                fadeIn.setAnimationListener(animHandler1)
                var text1 = findViewById<TextView>(R.id.textView1)
                var text2 = findViewById<TextView>(R.id.textView2)
                var text3 = findViewById<TextView>(R.id.phone)
                var text4 = findViewById<TextView>(R.id.player)
                text1.startAnimation(fadeIn)
                text2.startAnimation(fadeIn)
                text3.startAnimation(fadeIn)
                text4.startAnimation(fadeIn)
            }

        }
        override fun onAnimationStart(animation: Animation?)
        {
        }
    }
    /****************************************************************/

    /**************************FadeInHandler**********************************************/
    inner class FadeInHandler : Animation.AnimationListener
    {
        override fun onAnimationRepeat(animation: Animation?)
        {
        }
        override fun onAnimationEnd(animation: Animation?)
        {
        }
        override fun onAnimationStart(animation: Animation?)
        {
        }
    }
    /**********************************************************************************/

}